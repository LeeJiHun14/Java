package day01;

public class PrintTest {
	public static void main(String[] args) {
		
		// 주석
		// 1. 소스코드에 설명글을 달 때
		// 2. 지금 당장 사용하지 않는 코드를 번역하고 싶지 않을 때
		
		// 주석의 종류
		/*
		 * 1. 한줄주석 : Ctrl + /
		 * 2. 범위주석 : Ctrl + Shift + /, Ctrl + Shift + \
		 * 
		 */
		
		//이름을 출력하는 부분
//		System.out.print("한동석");
		
		//나이를 출력하는 부분
		System.out.print("20살");
	}
}






