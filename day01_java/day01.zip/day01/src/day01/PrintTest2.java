package day01;

public class PrintTest2 {
	public static void main(String[] args) {
		
		//제어 문자
		//반드시 따옴표 안에서 작성한다.
		
		/*
		 * \n	: new line, 줄바꿈, 개행문자
		 * \t	: tab, 위 아래 줄 간격 맞춰 띄기
		 * \"	: " 표현
		 * \'	: ' 표현
		 * \\	: \ 표현
		 */
		
//		System.out.print("\"한동석\"\n");
		System.out.println("한동석");
		System.out.print("20살");
		
	}
}
