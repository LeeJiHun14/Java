package day02;

public class CastingTest2 {
	public static void main(String[] args) {
		//자동 형변환
		char data = 67;
		System.out.println(data + 3);
	}
}
