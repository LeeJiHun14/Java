package day02;

public class CastingTest3 {
	public static void main(String[] args) {
		System.out.println(1 + "3" + 9);
		System.out.println("1" + 3 + 9);
		System.out.println(Integer.parseInt("1") + 3 + 9);
	}
}
