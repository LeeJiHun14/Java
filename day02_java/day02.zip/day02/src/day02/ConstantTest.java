package day02;

public class ConstantTest {
	public static void main(String[] args) {
		final int SALARY = 3000;
//		salary = 10000;	수정 불가
		System.out.println(SALARY);
	}
}
