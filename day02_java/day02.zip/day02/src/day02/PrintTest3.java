package day02;

public class PrintTest3 {
	public static void main(String[] args) {
		String data = null;
		int num = 10;
		int[] arData = {1, 3, 4, 5};
		
		System.out.println("들어옴1");
		System.out.println("들어옴2");
		num = 20;
		System.out.println("들어옴3");
		System.out.println("들어옴4");
		System.out.println(num);
		System.out.println("들어옴5");
	}
}
