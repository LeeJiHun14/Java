package day02;

public class Variable {
	public static void main(String[] args) {
		int age = 10;
		float interestRate = 2.5284F;
		double score = 2.5284;
		char grade = 'A';
		String data = "ABC";
		
		System.out.println(age + 5);
		System.out.println(interestRate);
		System.out.println(score);
		System.out.println(grade);
		System.out.println(data);
	}
}
