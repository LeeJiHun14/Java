package day03;

public class WhileTest {
	public static void main(String[] args) {
		// 이름 10번 출력
		
		int count = 0;
		
		while(count != 10) {
			count ++;
			System.out.println(count + ".한동석");
		}
	}
}
