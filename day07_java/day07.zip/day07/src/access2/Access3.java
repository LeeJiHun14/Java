package access2;

import access1.Access1;

public class Access3 extends Access1{
	public static void main(String[] args) {
//		Access1 a = new Access1();
		Access3 a = new Access3();
	}
}
