package casting;

public class Animation extends Video{
	void animate() {
		System.out.println("자막지원");
	}
}
