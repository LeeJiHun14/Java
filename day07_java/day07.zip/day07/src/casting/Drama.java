package casting;

public class Drama extends Video{
	void sellGoods() {
		System.out.println("굿즈");
	}
}
