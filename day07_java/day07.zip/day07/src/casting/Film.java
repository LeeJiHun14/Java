package casting;

public class Film extends Video{
	void playFilm() {
		System.out.println("4D");
	}
}
