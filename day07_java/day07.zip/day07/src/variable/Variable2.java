package variable;

public class Variable2 {
	public static void main(String[] args) {
//		편의성
//		System.out.println(Math.ceil(10.1));
		
//		Variable1 v1 = new Variable1();
//		Variable1 v2 = new Variable1();
//		
//		v1.data = 20;
//		System.out.println(v2.data);
//		
//		객체 간 공유
//		Variable1.data_s = 100;
//		System.out.println(Variable1.data_s);
		
		
//		Variable1 v = new Variable1();
//		Variable1.increaseData_s();
//		Variable1.increaseData_s();
//		Variable1.increaseData_s();
//		Variable1.increaseData_s();
//		Variable1.increaseData_s();
//		v = new Variable1();
//		Variable1.increaseData_s();
//		Variable1.increaseData_s();
//		Variable1.increaseData_s();
//		Variable1.increaseData_s();
//		Variable1.increaseData_s();
		
//		v.increaseData();
//		v.increaseData();
//		v.increaseData();
//		v.increaseData();
//		v.increaseData();
//		v = new Variable1();
//		v.increaseData();
//		v.increaseData();
//		v.increaseData();
//		v.increaseData();
//		v.increaseData();
	}
}
