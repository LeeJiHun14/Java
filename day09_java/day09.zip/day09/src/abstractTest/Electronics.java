package abstractTest;

public abstract class Electronics {
	abstract void on();
	abstract void off();
}
