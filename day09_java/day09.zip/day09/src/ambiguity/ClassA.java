package ambiguity;

public class ClassA {
	public void printData() {
		System.out.println("ClassA");
	}
}
