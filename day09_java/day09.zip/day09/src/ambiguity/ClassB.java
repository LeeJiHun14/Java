package ambiguity;

public class ClassB extends ClassA implements InterA{
	public static void main(String[] args) {
		new ClassB().printData();
	}
}
