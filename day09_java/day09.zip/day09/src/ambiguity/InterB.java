package ambiguity;

public interface InterB {
	default void printData() {
		System.out.println("InterB");
	}
}
