package anonymous;

public interface Form {
	public String[] getMenu();
	public void sell(String order);
}
