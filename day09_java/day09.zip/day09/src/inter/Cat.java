package inter;

public class Cat implements Pet {

	@Override
	public void sitDown() {
		System.out.println("퉷");
	}

	@Override
	public void stop() {
		System.out.println("퉷");
	}

	@Override
	public void poop() {
		System.out.println("알아서 잘 한다.");
	}

	@Override
	public void 빵야() {
		System.out.println("냥냥펀치");
	}
}






