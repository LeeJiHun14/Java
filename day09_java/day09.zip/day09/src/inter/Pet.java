package inter;

public interface Pet {
	final static int eyes = 2;
	int nose = 1;
	
	abstract void sitDown();
	void stop();
	void poop();
	void 빵야();
}
