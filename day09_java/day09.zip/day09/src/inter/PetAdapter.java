package inter;

public abstract class PetAdapter implements Pet {

	@Override
	public void sitDown() {}

	@Override
	public void stop() {}

	@Override
	public void poop() {}

	@Override
	public void 빵야() {}
}
