package inter;

public interface Soldier {
	int arm = 2;
	int leg = 2;
	
	void saulte();
	void work();
	void eat();
	void sleep();
	
}
