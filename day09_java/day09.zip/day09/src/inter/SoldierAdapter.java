package inter;

public abstract class SoldierAdapter implements Soldier {

	@Override
	public void saulte() {} //중괄호 : 바디

	@Override
	public void work() {}

	@Override
	public void eat() {}

	@Override
	public void sleep() {}
}
