package marker;

public class Animal {

}
