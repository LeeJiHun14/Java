package marker;

public class Bear extends Animal implements Carbivore{

}
