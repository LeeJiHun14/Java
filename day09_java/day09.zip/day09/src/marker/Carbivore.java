package marker;

public interface Carbivore {;}
