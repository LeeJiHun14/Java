package marker;

public class Cow extends Animal implements Herbivore{
	public void printIntro() {
		System.out.println("저는 소입니다.");
	}
}
