package marker;

public class Dog extends Animal{

}
