package marker;

public interface Herbivore {;}
