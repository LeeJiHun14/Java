package marker;

public class Tiger extends Animal implements Carbivore{

}
