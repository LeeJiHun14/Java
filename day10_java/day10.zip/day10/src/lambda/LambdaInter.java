package lambda;

@FunctionalInterface
public interface LambdaInter {
	boolean checkMultipleOf10(int number);
}
