package lambda;

@FunctionalInterface
public interface MyMath {
	public int calc(int num1, int num2);
}
