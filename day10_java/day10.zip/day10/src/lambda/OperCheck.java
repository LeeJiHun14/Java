package lambda;

@FunctionalInterface
public interface OperCheck {
	public String[] getOpers(String expression);
}
