package myApi;

import api.MyMath;

public class ApiTest {
	public static void main(String[] args) {
		MyMath math = new MyMath();
		math.div(10, 3);
	}
}
